%Colciago Silvestrini (2020)
 clear all
 close all;
 clc

%Estimate VAR, produces IRFs with boostraped confidence intervals  

addpath('functions');

load EEREV_D_21_00292_data_quarterly  % matrix with data


%from this Table one can see the name of variables and dates

lunghezza=size(data,1); % number of rows of the table (periods in sample +1)
larghezza=size(data,2); % number of columns in the table (number of variables +1)                        
EEREV_D_21_00292_data_quarterly=data(((2:lunghezza)),(2:larghezza));

%transform in an array
data_quarterly=table2array(EEREV_D_21_00292_data_quarterly);

%Create vectors [Y1, FFR, Y2], as in the paper.

% Y1= GDP(1),Consumption(2),Inflation(3),Investment(4),Wage(5),Average Productivity labor (6),Entry (7)
% Y2= Profits(9),growth of M2(10). 


Y1=[data_quarterly(:,1), data_quarterly(:,2), data_quarterly(:,9) data_quarterly(:,4) data_quarterly(:,5) data_quarterly(:,13) data_quarterly(:,10)];
FFR=[data_quarterly(:,6)];
Y2=[data_quarterly(:,7), data_quarterly(:,8)];


index_ffr=size(Y1,2)+1;

data_base=[Y1,FFR, Y2];

% In real terms. 

% estimation

[VAR_base, VARopt] = VARmodel(data_base,4,1); % input: matrix with data, lags, constant or not 

VARopt.impact    = 0;  %0 for 1std, 1 for unit 

VARopt.pctg      = 68;      %confidence level for bootstrap

VARopt.vnames = {'GDP','Consumption','Inflation','Investment','Wage','Average Productivity','Entry','FFR','Profits','M2'};


% IRFs, Cholesky identification

[IR, VAR] = VARir(VAR_base,VARopt);

% IRFs confidence bands computed with boostrapping, can change bands above above

[INF_68,SUP_68,MED_68,BAR_68] = VARirband(VAR_base,VARopt);

% we are interested in the response to a shock to he FFR which has Index
% index_ffr

IRF_ffr=IR(:,:,index_ffr);
INF_68_ffr=INF_68(:,:,index_ffr);
SUP_68_ffr=SUP_68(:,:,index_ffr);
MED_68_ffr=MED_68(:,:,index_ffr);
BAR_68_ffr=BAR_68(:,:,index_ffr);

log_indices=[1 2 4 5 6 9];

PLOT_68(:,:,1)=MED_68_ffr;
PLOT_68(:,:,2)=SUP_68_ffr;
PLOT_68(:,:,3)=INF_68_ffr;

PLOT_68(:,log_indices,:) = 100*(exp(PLOT_68(:,log_indices,:))-1);

% %reverse sign-->expansionary shock
PLOT_68 = -PLOT_68;

save  PLOT_68  PLOT_68

length_irf=20; 
tempore=1:1:20; 


close all



figure(1)
% 
subplot (3,4,1)
plot(tempore,PLOT_68((1:length_irf),1,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),1,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),1,3),'r-')
title ('Real GDP') 


subplot (3,4,2)
plot(tempore,PLOT_68((1:length_irf),2,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),2,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),2,3),'r-')
title ('Real Consumption') 

subplot (3,4,3)
plot(tempore,PLOT_68((1:length_irf),3,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),3,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),3,3),'r-')
title ('Inflation')


subplot (3,4,4)
plot(tempore,PLOT_68((1:length_irf),5,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),5,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),5,3),'r-')
title ('Real Wage')



subplot (3,4,5)
plot(tempore,PLOT_68((1:length_irf),4,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),4,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),4,3),'r-')
title ('Investment')


subplot (3,4,6)
plot(tempore,PLOT_68((1:length_irf),9,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),9,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),9,3),'r-')
title ('Profits')


subplot (3,4,7)
plot(tempore,PLOT_68((1:length_irf),10,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),10,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),10,3),'r-')
title ('M2')


subplot (3,4,8)
plot(tempore,PLOT_68((1:length_irf),8,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),8,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),8,3),'r-')
title ('Federal Funds Rate')


subplot (3,4,9)
plot(tempore,PLOT_68((1:length_irf),6,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),6,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),6,3),'r-')
title ('Average Productivity')



subplot (3,4,10)
plot(tempore,PLOT_68((1:length_irf),7,1),'k-')
hold on
plot(tempore,PLOT_68((1:length_irf),7,2),'b-')
hold on
plot(tempore,PLOT_68((1:length_irf),7,3),'r-')
title ('Entry Rate')
