Folder VAR benchmark

1. EEREV_D_21_00292_data_quarterly is the final dataset used for the estimation.

2. EEREV_D_21_00292_VARbenchmark_68 and _95 generate the IRFs with bootstrapped .68 and .95 confidence bands, respectively. These files generate the output PLOT_68 and _95, used by the plotter.

3. EEREV_D_21_00292_plot_VARbenchmark plots Figure 1 of the paper.

4. The subfolder "functions" contains the function shade.m, used by the plotter, and the functions to estimate the VAR from the toolbox by Ambrogio Cesa-Bianchi, which is available at https://sites.google.com/site/ambropo/MatlabCodes?authuser=0