%Colciago Silvestrini (2020)
clear all
close all;
clc

% wrt to the baseline I removed : Consumption, wage and profits 

% investment helps identifying the response of output and inflation, thus 
% helps identifiyng an actual MP shock. M2 not necessary but its response 
% again shows we are identifying a MP shock. 


%Estimate VAR, produces IRFs with boostraped confidence intervals  

addpath('functions');

load EEREV_D_21_00292_data_quarterly  % matrix with data


%from this Table one can see the name of variables and dates

lunghezza=size(data,1); % number of rows of the table (periods in sample +1)
larghezza=size(data,2); % number of columns in the table (number of variables +1)                        
EEREV_D_21_00292_data_quarterly=data(((2:lunghezza)),(2:larghezza));

%transform in an array
data_quarterly=table2array(EEREV_D_21_00292_data_quarterly);


%Create vectors [Y1, FFR, Y2], as in the paper.


%in the parsimonous VAR
% Y1= GDP,Inflation,Investment,Average Productivity CD,Entry
% Y2= M2. 


Y1=[data_quarterly(:,1), data_quarterly(:,9),data_quarterly(:,4), data_quarterly(:,14) data_quarterly(:,10)];
FFR=[data_quarterly(:,6)];
Y2=[data_quarterly(:,8)];

data_parsi=[Y1,FFR, Y2];

% In real terms. 

% estimation with OLS 

[VAR_parsi, VARopt] = VARmodel(data_parsi,4,1); % input: matrix with data, lags, constant or not 

VARopt.impact    = 0; 

VARopt.pctg      = 95;      %confidence level for bootstrap

VARopt.vnames = {'GDP', 'Inflation','Investment','Average Productivity CD','Entry','FFR','M2'};


% IRFs, Cholesky identification

[IR, VAR] = VARir(VAR_parsi,VARopt);

% IRFs confidence bands computed with boostrapping (95%), can change the
% confidence level in the routine

% IRFs confidence bands computed with boostrapping, can change bands above above

[INF_95,SUP_95,MED_95,BAR_95] = VARirband(VAR_parsi,VARopt);

% we are interested in the response to a shock to he FFR which has Index
% index_ffr

index_ffr=size(Y1,2)+1;

IRF_ffr=IR(:,:,index_ffr);
INF_95_ffr=INF_95(:,:,index_ffr);
SUP_95_ffr=SUP_95(:,:,index_ffr);
MED_95_ffr=MED_95(:,:,index_ffr);
BAR_95_ffr=BAR_95(:,:,index_ffr);



log_indices=[1 3 4];

%PLOT_95(:,:,1)=IRF_ffr;
PLOT_95(:,:,1)=MED_95_ffr;
PLOT_95(:,:,2)=SUP_95_ffr;
PLOT_95(:,:,3)=INF_95_ffr;

PLOT_95(:,log_indices,:) = 100*(exp(PLOT_95(:,log_indices,:))-1);

% %reverse sign-->expansionary shock
PLOT_95 = -PLOT_95;

save  PLOT_95_parsi   PLOT_95


