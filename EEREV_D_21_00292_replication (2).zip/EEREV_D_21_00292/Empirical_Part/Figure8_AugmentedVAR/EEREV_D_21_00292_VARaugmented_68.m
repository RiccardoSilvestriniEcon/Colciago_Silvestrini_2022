%Colciago Silvestrini (2020)
 clear all
 close all;
 clc

%Estimate VAR, produces IRFs with boostraped confidence intervals  

addpath('functions');

load EEREV_D_21_00292_data_quarterly  % matrix with data


%from this Table one can see the name of variables and dates

lunghezza=size(updated_table,1); % number of rows of the table (periods in sample +1)
larghezza=size(updated_table,2); % number of columns in the table (number of variables +1)                        
EEREV_D_21_00292_data_quarterly=updated_table(((2:lunghezza)),(2:larghezza));

%transform in an array
data_quarterly=table2array(EEREV_D_21_00292_data_quarterly);

% generate logged demeaned S&P500 index

load SandP500

SandP500=SandP500(2:lunghezza);
SandP500=log(SandP500);
meanSP500=mean(SandP500);
demSP500=SandP500-meanSP500;

%Create vectors [Y1, FFR, Y2], as in the paper.

% Y1= GDP,Consumption,Inflation,Investment,Wage,Average Productivity CD, 
% Entry, BAA
% Y2= Profits,growth of M2, S&P500


Y1=[data_quarterly(:,1), data_quarterly(:,2), data_quarterly(:,9) data_quarterly(:,4) data_quarterly(:,5) data_quarterly(:,14) data_quarterly(:,10) data_quarterly(:,41)];
FFR=[data_quarterly(:,6)];
Y2=[data_quarterly(:,7), data_quarterly(:,8) demSP500];



index_ffr=size(Y1,2)+1;
data_sp=[Y1,FFR, Y2];

% In real terms. 

% estimation VAR

[VAR_sp, VARopt] = VARmodel(data_sp,4,1); % input: matrix with data, lags, constant or not 

VARopt.impact    = 0; 

VARopt.pctg      = 68;      %confidence level for bootstrap

VARopt.vnames = {'GDP','Consumption','Inflation','Investment','Wage','Average Productivity CD','Entry','BAA','FFR','Profits','M2','S&P500'};


% IRFs, Cholesky identification

[IR, VAR] = VARir(VAR_sp,VARopt);

% IRFs confidence bands computed with boostrapping (95%), can change above

[INF_68,SUP_68,MED_68,BAR_68] = VARirband(VAR_sp,VARopt);


IRF_ffr=IR(:,:,index_ffr);
INF_68_sp_ffr=INF_68(:,:,index_ffr);
SUP_68_sp_ffr=SUP_68(:,:,index_ffr);
MED_68_sp_ffr=MED_68(:,:,index_ffr);
BAR_68_sp_ffr=BAR_68(:,:,index_ffr);

log_indices=[1 2 4 5 6 10 12];

PLOT_68_sp(:,:,1)=MED_68_sp_ffr;
PLOT_68_sp(:,:,2)=SUP_68_sp_ffr;
PLOT_68_sp(:,:,3)=INF_68_sp_ffr;

PLOT_68_sp(:,log_indices,:) = 100*(exp(PLOT_68_sp(:,log_indices,:))-1);

% %reverse sign-->expansionary shock
PLOT_68_sp = -PLOT_68_sp;

save  PLOT_68_sp  PLOT_68_sp
