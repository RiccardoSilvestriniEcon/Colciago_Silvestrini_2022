
clear all
close all;
clc

addpath('functions');

%Colciago Silvestrini (2020)
load Plot_68_sector
load Plot_95_sector

length_irf=20;
tempore=1:1:length_irf;

%notice that 

%PLOT_xx(:,:,1) is the median point estimate of the IRF
%PLOT_xx(:,:,2) is the upper bound of the xx confidence band ;
%PLOT_xx(:,:,3) is the lower bound of the xx confidence band;


figure(1)
subplot (3,4,1)
shade(tempore,PLOT_68_sector((1:length_irf),1,2),'k',tempore,PLOT_68_sector((1:length_irf),1,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),1,2),'k',tempore,PLOT_95_sector((1:length_irf),1,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),1,1),'k-','linewidth', 3);
title ('GDP') 
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,2)
shade(tempore,PLOT_68_sector((1:length_irf),2,2),'k',tempore,PLOT_68_sector((1:length_irf),2,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),2,2),'k',tempore,PLOT_95_sector((1:length_irf),2,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),2,1),'k-','linewidth', 3);
title ('Consumption') 
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)


subplot (3,4,3)
shade(tempore,PLOT_68_sector((1:length_irf),3,2),'k',tempore,PLOT_68_sector((1:length_irf),3,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),3,2),'k',tempore,PLOT_95_sector((1:length_irf),3,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),3,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Inflation') 
ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)


subplot (3,4,4)
shade(tempore,PLOT_68_sector((1:length_irf),5,2),'k',tempore,PLOT_68_sector((1:length_irf),5,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),5,2),'k',tempore,PLOT_95_sector((1:length_irf),5,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),5,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Real Wage')
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,5)
shade(tempore,PLOT_68_sector((1:length_irf),4,2),'k',tempore,PLOT_68_sector((1:length_irf),4,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),4,2),'k',tempore,PLOT_95_sector((1:length_irf),4,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),4,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Investment')
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,6)
shade(tempore,PLOT_68_sector((1:length_irf),11,2),'k',tempore,PLOT_68_sector((1:length_irf),11,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),11,2),'k',tempore,PLOT_95_sector((1:length_irf),11,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),11,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Profits')
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,7)
shade(tempore,PLOT_68_sector((1:length_irf),12,2),'k',tempore,PLOT_68_sector((1:length_irf),12,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),12,2),'k',tempore,PLOT_95_sector((1:length_irf),12,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),12,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('M2')
ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,8)
shade(tempore,PLOT_68_sector((1:length_irf),10,2),'k',tempore,PLOT_68_sector((1:length_irf),10,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),10,2),'k',tempore,PLOT_95_sector((1:length_irf),10,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),10,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Federal Funds Rate')
ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,9)
shade(tempore,PLOT_68_sector((1:length_irf),6,2),'k',tempore,PLOT_68_sector((1:length_irf),6,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),6,2),'k',tempore,PLOT_95_sector((1:length_irf),6,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),6,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Average Productivity')
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,10)
shade(tempore,PLOT_68_sector((1:length_irf),7,2),'k',tempore,PLOT_68_sector((1:length_irf),7,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),7,2),'k',tempore,PLOT_95_sector((1:length_irf),7,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),7,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Entry Rate')
ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,11)
shade(tempore,PLOT_68_sector((1:length_irf),8,2),'k',tempore,PLOT_68_sector((1:length_irf),8,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),8,2),'k',tempore,PLOT_95_sector((1:length_irf),8,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),8,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Entry rate: Utilities ')
ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)



subplot (3,4,12)
shade(tempore,PLOT_68_sector((1:length_irf),9,2),'k',tempore,PLOT_68_sector((1:length_irf),9,3),'k','FillType',[1 2;2 1],'FillColor',[0. 0. 0.]);
hold on
shade(tempore,PLOT_95_sector((1:length_irf),9,2),'k',tempore,PLOT_95_sector((1:length_irf),9,3),'k','FillType',[1 2;2 1],'FillColor',[0.1 0.1 0.1]);
hold on, 
plot(tempore,PLOT_95_sector((1:length_irf),9,1),'k-','linewidth', 3);
xlim([1 20])
xticks([5 10 15 20]);
xticklabels({'5','10','15','20'})
title ('Average Productivity: Utilities ')
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)

set(gcf,'renderer','Painters')

saveas(gcf,'Figure_2');
