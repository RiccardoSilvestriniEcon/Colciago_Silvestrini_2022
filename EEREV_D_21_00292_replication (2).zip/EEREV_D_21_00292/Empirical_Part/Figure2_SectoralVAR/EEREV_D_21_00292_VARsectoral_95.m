%Colciago Silvestrini (2020)
 clear all
 close all;
 clc

%Estimate VAR, produces IRFs with boostraped confidence intervals  

addpath('functions');

load EEREV_D_21_00292_data_quarterly  % matrix with data


%from this Table one can see the name of variables and dates

lunghezza=size(data,1); % number of rows of the table (periods in sample +1)
larghezza=size(data,2); % number of columns in the table (number of variables +1)                        
EEREV_D_21_00292_data_quarterly=data(((2:lunghezza)),(2:larghezza));

%transform in an array
data_quarterly=table2array(EEREV_D_21_00292_data_quarterly);

%Create vectors [Y1, FFR, Y2], as in the paper.

% Y1= GDP(1),Consumption(2),Inflation(3),Investment(4),Wage(5),Average
% Productivity CD (6),Entry (7), entry utilities (8), prod_cd_utilities (9)

% Y2= Profits(11),growth of M2(12). 


Y1=[data_quarterly(:,1), data_quarterly(:,2), data_quarterly(:,9) data_quarterly(:,4) data_quarterly(:,5) data_quarterly(:,14) data_quarterly(:,10) data_quarterly(:,18) data_quarterly(:,38)  ];
FFR=[data_quarterly(:,6)];
Y2=[data_quarterly(:,7), data_quarterly(:,8)];


index_ffr=size(Y1,2)+1;

data_sector=[Y1,FFR, Y2];

% In real terms. 

[VAR_sector, VARopt] = VARmodel(data_sector,4,1); % input: matrix with data, lags, constant or not 

VARopt.impact    = 0;  %0 for 1std, 1 for unit 

VARopt.pctg      = 95;      %confidence level for bootstrap

VARopt.vnames = {'GDP','Consumption','Inflation','Investment','Wage','Average Productivity CD','Entry', 'entry utilities', 'prod_cd_utilities','FFR','Profits','M2'};


% IRFs, Cholesky identification

[IR, VAR] = VARir(VAR_sector,VARopt);

% IRFs confidence bands computed with boostrapping, can change bands above above

[INF_95,SUP_95,MED_95,BAR_95] = VARirband(VAR_sector,VARopt);

% we are interested in the response to a shock to he FFR which has Index
% index_ffr

IRF_ffr=IR(:,:,index_ffr);
INF_95_ffr=INF_95(:,:,index_ffr);
SUP_95_ffr=SUP_95(:,:,index_ffr);
MED_95_ffr=MED_95(:,:,index_ffr);
BAR_95_ffr=BAR_95(:,:,index_ffr);

log_indices=[1 2 4 5 6 9 11];

PLOT_95_sector(:,:,1)=MED_95_ffr;
PLOT_95_sector(:,:,2)=SUP_95_ffr;
PLOT_95_sector(:,:,3)=INF_95_ffr;

PLOT_95_sector(:,log_indices,:) = 100*(exp(PLOT_95_sector(:,log_indices,:))-1);

% %reverse sign-->expansionary shock
PLOT_95_sector = -PLOT_95_sector;

save  PLOT_95_sector  PLOT_95_sector
