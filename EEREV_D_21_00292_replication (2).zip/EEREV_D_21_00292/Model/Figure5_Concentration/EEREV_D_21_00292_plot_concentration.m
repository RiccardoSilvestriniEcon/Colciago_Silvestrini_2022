clear all;

load irf_competitive;
load irf_granular; 

irf_benchmark=irf_granular;
length_irf=length(irf_competitive(:,1));

figure(1)

subplot(1,2,1)
plot((1:1:length_irf),irf_competitive(:,14),'b:','lineWidth',3)
hold on
plot((1:1:length_irf),irf_benchmark(:,14),'r-','lineWidth',2)
hold on
plot((1:1:length_irf),zeros(length_irf,1),'k-','lineWidth',1)
title('Average Productivity','fontsize',14)
ylabel('Percentages','FontSize',11)
xticks([1 5 10 15 20])
xticklabels({'0','5','10','15','20'})
xlim([1 20])
xlabel('Quarters','fontsize',14)



subplot(1,2,2)
plot((1:1:length_irf),irf_competitive(:,19),'b:','lineWidth',3)
hold on 
plot((1:1:length_irf),irf_benchmark(:,19),'r-','lineWidth',2)
title('Entry Rate','fontsize',14)
ylabel('Percentage Points','FontSize',11)
xticks([1 5 10 15 20])
xticklabels({'0','5','10','15','20'})
xlim([1 20])
xlabel('Quarters','fontsize',14)
plot((1:1:length_irf),zeros(length_irf,1),'k-','lineWidth',1)

legend('Low Concentration','Baseline')

saveas(gcf,'Figure_5');
