%%%%%%% Benchmark Model with Habits, WC, Congestion, Hetero Firms, Form1

clear all;

%%%%%% change parameters also in the function at the end

theta=3.8;

kappa=8.09;

zmin=1;

Z=1;

psi0=1;

psi1=100;

gamma=1.5;

fx=0.27;

thetaw=4;

delta=0.025;

betta=0.99;

alphatilde=0.75;

phi=4;

nu=(kappa/(kappa-(theta-1)))^(1/(theta-1));

chi=1;

alphaw=1;

b=0.8;



fun=@equilibrium;

x0=[1.15,1.15,1.15];
    
lb=[0,0,0];
   
ub=[1000,1000,1000];

options = optimoptions(@lsqnonlin,'MaxFunctionEvaluations',100000,'StepTolerance',1e-18,'FunctionTolerance',1e-18,'MaxIterations',10000);

y=lsqnonlin(fun,x0,lb,ub,options);


zc=y(1);

n=y(2);

c=y(3);


fe=psi0+psi1*(delta/(1-delta)*n)^gamma;

w=1/(alphaw/betta+1-alphaw)*Z*nu*zc*(theta-1)/theta*(n*(zmin/zc)^kappa)^(1/(theta-1));

stilde=1;

pi=1;

wtilde=w;

mutilde=(thetaw)/(thetaw-1);

lambda=1/c*(1-b*betta)/(1-b);

Ls=(w*lambda/(chi*mutilde))^phi;

Ld=Ls;

f1=w^(thetaw)*lambda*Ld/(1-alphatilde*betta);

f2=w^(thetaw)*Ld*chi*(Ls)^(1/phi)/(1-alphatilde*betta);

d=(c+fe*delta/(1-delta)*n+n*fx*(zmin/zc)^kappa)/(theta*n*(zmin/zc)^kappa)-fx;

R=1/betta;

ne=delta/(1-delta)*n;

e=fe;

Y=c+ne*fe+fx*n*(zmin/zc)^kappa;

rho=(n*(zmin/zc)^kappa)^(1/(theta-1));

ztilde=nu*zc;

no=n*(zmin/zc)^kappa;

HHI=theta*(kappa-(theta-1))/(kappa-2*(theta-1))*fx/Y;

n_HHI=(HHI-(1/n))/(1-(1/n));

save SS_model_altkappa y



x(1)=e-betta*(1-delta)*(lambda/lambda)*(e+(zmin/zc)^(kappa)*d);

x(2)=1-betta*(lambda/lambda)*R/pi;

x(3)=e-fe;

x(4)=n-(1-delta)*(n+ne);

x(5)=rho-theta/(theta-1)*w*(alphaw*R+1-alphaw)/(Z*ztilde);

x(6)=c+ne*fe-(alphaw*R+1-alphaw)*w*Ld-no*d;

x(7)=d-1/theta*rho^(1-theta)*Y+fx;

x(8)=wtilde-f2/f1*thetaw/(thetaw-1);

x(9)=f1-w^(thetaw)*lambda*Ld-alphatilde*betta*pi^(thetaw-1)*f1;

x(10)=f2-chi*(Ls)^(1/phi)*w^(thetaw)*Ld-alphatilde*betta*pi^(thetaw)*f2;

x(11)=1-rho^(1-theta)*no;

x(12)=Y-c-ne*fe-fx*no;

x(13)=w^(1-thetaw)-(1-alphatilde)*wtilde^(1-thetaw)-alphatilde*(w/pi)^(1-thetaw);

x(14)=Ls-stilde*Ld;

x(15)=stilde-(1-alphatilde)*(wtilde/w)^(-thetaw)-alphatilde*pi^(thetaw)*stilde;

x(16)=chi*Ls^(1/phi)-w*lambda/mutilde;

x(17)=ztilde-nu*zc;

x(18)=zc-(theta^(theta/(theta-1)))/(theta-1)*(alphaw*R+1-alphaw)*w/Z*(fx/Y)^(1/(theta-1));

x(19)=no-n*(zmin/zc)^kappa;

x(20)=lambda-(c-b*c*(1+betta)+betta*b^2*c)/((c-b*c)*(c-b*c));

x(21)=HHI-theta*(kappa-(theta-1))/(kappa-2*(theta-1))*fx/Y;

x(22)=fe-psi0-psi1*(ne)^gamma;



function F=equilibrium(x)

theta=3.8;

kappa=8.09;

zmin=1;

Z=1;

psi0=1;

psi1=100;

gamma=1.5;

fx=0.27;

thetaw=4;

delta=0.025;

betta=0.99;

phi=4;

nu=(kappa/(kappa-(theta-1)))^(1/(theta-1));

chi=1;

alphaw=1;

b=0.8;


fe=psi0+psi1*(delta/(1-delta)*x(2))^gamma;

lambda=1/x(3)*(1-b*betta)/(1-b);



F(1)=x(3)+delta/(1-delta)*x(2)*fe-(((zmin/x(1))^kappa*x(2))^(1/(theta-1))*(theta-1)/theta*Z*nu*x(1))^(phi+1)*(alphaw/betta+1-alphaw)^(-phi)*(lambda*(thetaw-1)/(chi*thetaw))^phi-x(2)*fe*(1-betta*(1-delta))/(betta*(1-delta));

F(2)=fe*(1-betta*(1-delta))/(betta*(1-delta)*(zmin/x(1))^kappa)-(x(3)+delta/(1-delta)*x(2)*fe+(zmin/x(1))^kappa*x(2)*fx)/(theta*(zmin/x(1))^kappa*x(2))+fx;

F(3)=x(1)-theta^(theta/(theta-1))/theta*nu*x(1)*((zmin/x(1))^kappa*x(2))^(1/(theta-1))*((x(3)+delta/(1-delta)*x(2)*fe+(zmin/x(1))^kappa*x(2)*fx)/fx)^(1/(1-theta));

end