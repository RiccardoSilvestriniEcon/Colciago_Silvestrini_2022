Folder Model Concentration (MATLAB version R2018B, dynare version 4.6.1)

1. EEREV_D_21_00292_steadystate computes the steady state of the economy. The latter is stored as SS_model and serves as an input for the benchmark model

2. EEREV_D_21_00292_ss_alternativekappa computes the steady state of the economy for kappa=8.09. The latter is stored as SS_model_altkappa and serves as an input for the alternative model

3. EEREV_D_21_00292_wage_stickiness.mod is the dynare model file for the benchmark model. It generates impulse response functions stored as irf_granular

4. EEREV_D_21_00292_ws_alternativekappa.mod is the dynare model file for the alternative model. It generates impulse response functions stored as irf_competitive

5. EEREV_D_21_00292_plot_concentration uses the output of the .mod files (irf_granular, _competitive) to plot Figure 5 of the paper.
