load irf_expMP_w 
horz=51;
periodi=horz-1;
time=0:1:horz-1;
fsize=12;

%irf_expMP_w=[change_ne change_zc change_agg_profits change_mu change_Y change_c change_pi change_pip change_n change_R change_d change_Ls change_w change_ztilde change_rR change_agg_prod change_Z change_no change_er change_er_no change_or];
 %              1           2      3                    4         5       6        7           8        8         10

figure(1);

subplot(1,3,1)
plot(time(1:end-1),irf_expMP_w(:,14),'k-','LineWidth',3);hold on
plot(time(1:end-1),zeros(1,horz-1),'k-','LineWidth',1);
hold off
%box off;
ylabel('Percentages','FontSize',12)
xlabel('Quarters','FontSize',12)
title('Average Productivity','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])

subplot(1,3,2)
plot(time(1:end-1),irf_expMP_w(:,19),'k-','LineWidth',3);hold on
plot(time(1:end-1),zeros(1,horz-1),'k-','LineWidth',1);
hold off
%box off;
ylabel('Percentage Points','FontSize',12)
xlabel('Quarters','FontSize',12)
title('Entry Rate','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])


subplot(1,3,3)
plot(time(1:end-1),irf_expMP_w(:,10),'k-','LineWidth',3);hold on
plot(time(1:end-1),zeros(1,horz-1),'k-','LineWidth',1);
ylabel('Percentage Points','FontSize',12)
xlabel('Quarters','FontSize',12)
title('Nominal Interest Rate','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])

saveas(gcf,'Figure_3');
