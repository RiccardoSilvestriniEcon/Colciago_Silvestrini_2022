Folder benchmark Model (MATLAB version R2018B, dynare version 4.6.1)

1. EEREV_D_21_00292_steadystate computes the steady state of the economy. The latter is stored as SS_model and serves as an input for the model

2. EEREV_D_21_00292_wage_stickiness.mod is the dynare model file for the benchmark model. It generates impulse response functions stored as irf_expMP_w

3. EEREV_D_21_00292_plot_wage_stickiness_fig3 and _fig4 use the output of the .mod file (irf_expMP_w) to plot Figure 3 and 4 of the paper.
