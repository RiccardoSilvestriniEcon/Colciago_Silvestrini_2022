Folder Model stickiness robustness (MATLAB version R2018B, dynare version 4.6.1)

1. EEREV_D_21_00292_steadystate computes the steady state of the economy. The latter is stored as SS_model and serves as an input for the three models

2. EEREV_D_21_00292_wage_stickiness.mod is the dynare model file for the benchmark model with wage stickiness. It generates impulse response functions stored as irf_expMP_w

3. EEREV_D_21_00292_price_stickiness.mod is the dynare model file for the model with price stickiness. It generates impulse response functions stored as irf_expMP_p

4. EEREV_D_21_00292_pandw_stickiness.mod is the dynare model file for the model with both price and wage stickiness. It generates impulse response functions stored as irf_expMP_pw

5. EEREV_D_21_00292_plot_stickiness uses the output of the .mod files (irf_expMP_w, _p and _pw) to plot Figure 6 of the paper.
