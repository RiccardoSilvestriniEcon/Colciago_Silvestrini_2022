clear all;
close all
clc;
 

load('irf_expMP_w');
NE1=irf_expMP_w(:,19);
load('irf_expMP_pw');
NE2=irf_expMP_pw(:,19);
load('irf_expMP_p');
NE3=irf_expMP_p(:,19);

load('irf_expMP_w');
zc1=irf_expMP_w(:,2);
load('irf_expMP_pw');
zc2=irf_expMP_pw(:,2);
load('irf_expMP_p');
zc3=irf_expMP_p(:,2);

load('irf_expMP_w');
agg_p1=irf_expMP_w(:,3);
load('irf_expMP_pw');
agg_p2=irf_expMP_pw(:,3);
load('irf_expMP_p');
agg_p3=irf_expMP_p(:,3);



fsize=11;
horz=51;
periodi=horz-1;
time=0:1:horz-1;

figure;

subplot(1,3,1)
plot(time(1:end-1),zc1,'g-','LineWidth',1.5);hold on
plot(time(1:end-1),zc2,'r:','LineWidth',1.5);hold on
plot(time(1:end-1),zc3,'b--','LineWidth',1.5);hold on
plot(time(1:end-1),zeros(1,length(zc3)),'k-','LineWidth',1)

hold off
%box off;
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)
title('Average Productivity','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])

subplot(1,3,2)
plot(time(1:end-1),NE1,'g-','LineWidth',1.5);hold on
plot(time(1:end-1),NE2,'r:','LineWidth',1.5);hold on
plot(time(1:end-1),NE3,'b--','LineWidth',1.5);hold off
hold on
plot(time(1:end-1),zeros(1,length(zc3)),'k-','LineWidth',1)%box off;

ylabel('Percentage Points','FontSize',11)
xlabel('Quarters','FontSize',11)
title('Entry Rate','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])

subplot(1,3,3)
plot(time(1:end-1),agg_p1,'g-','LineWidth',1.5);hold on
plot(time(1:end-1),agg_p2,'r:','LineWidth',1.5);hold on
plot(time(1:end-1),agg_p3,'b--','LineWidth',1.5);hold off
legend('Wage Stickiness','Wage and Price Stickiness', 'Price Stickiness')
hold on
plot(time(1:end-1),zeros(1,length(zc3)),'k-','LineWidth',1)%box off;

ylabel('Percentage Deviations','FontSize',11)
xlabel('Quarters','FontSize',11)
ylabel('Percentages','FontSize',11)
xlabel('Quarters','FontSize',11)
title('Aggregate profits','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([0 20])


legend('Wage Stickiness','Wage and Price Stickiness', 'Price Stickiness')

saveas(gcf,'Figure_6');